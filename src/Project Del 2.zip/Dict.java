/*
        MADE BY Mathias Gundersen(MGUND15), D3 AND Daniel Jørgensen(DANJO14), D3
*/

public interface Dict {

    public void insert(Integer k);

    public int[] orderedTraversal();

    public Boolean search(Integer k);
}

